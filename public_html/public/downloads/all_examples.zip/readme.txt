This folder contains all our Examples, Tutorials, Exercises and Answers.

Note: University PC's version of BlueJ does not appear to contain the very latest version of Pi4J. This can lead to compilation errors with the Speaker class and dependants. 

We have included the latest version in the "lib" folder of each project.